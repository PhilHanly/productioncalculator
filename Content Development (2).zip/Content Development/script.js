document.getElementById('calculate-btn').addEventListener('click', function() {
  // Input values
  const users = parseFloat(document.getElementById('input1').value) || 0;
  const costPerUser = parseFloat(document.getElementById('input2').value) || 0;
  const productivityGain = parseFloat(document.getElementById('input3').value) || 0;

  // Calculations
  const totalCost = users * costPerUser;
  const roi = totalCost * (productivityGain / 100);

  // Display results
  document.getElementById('total-cost').textContent = `R${totalCost.toFixed(2)}`;
  document.getElementById('roi').textContent = `R${roi.toFixed(2)}`;
});
